function u_outlet = lsl_outlet_setup()
    %%Set up LSL Outlet for Unity
    lib = lsl_loadlib();
    disp('Setting up new LSL Outlet for Unity...');
    u_info = lsl_streaminfo(lib, 'CubeStream', 'Cubes', 1, 0, 'cf_string', 'myuniquesourceid23444');
    u_outlet = lsl_outlet(u_info);
end