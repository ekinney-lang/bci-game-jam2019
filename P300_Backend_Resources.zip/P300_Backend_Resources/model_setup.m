function model = model_setup(filename, targetMarkerOrder,visFlag,optimizeFlag)
    %%Calibrate BCILAB model using BCI_Train
    
    %Sanity checks
    [filepath, name, ext] = fileparts(filename);
    
    %Checking filename
    while ~ischar(filename) || ~strcmp(ext, {'.xdf'}) 
        disp('Incorrect filename format, must be a char array and have extension `.xdf`');
        filename = input('filename: ');
        [filepath, name, ext] = fileparts(filename);
    end
    
    %Checking Target Marker Order
    disp(isempty(targetMarkerOrder));
    while ~iscell(targetMarkerOrder) || isempty(targetMarkerOrder)
        disp('Incorrect Target Marker Order format, must be a string cell array');
        targetMarkerOrder = input('target marker order: ');
    end
    % Load in the XDF information to train a BCI Model
    % Must include specific target marker information in a cell array
    %trainData = eeg_load_xdf_ekl(filename, 'exclude_markerstreams', {'gUSBamp-1Markers'}, 'targetMarkerOrder', targetMarkerOrder);
    trainData = eeg_load_xdf_ekl_v2_RC(filename, 'exclude_markerstreams', {'gUSBamp-1Markers'}, 'targetMarkerOrder', targetMarkerOrder);

    
    %If optimizeFlag is true, just change a few hyperparameters via a grid
    %search. We will select the model which optimizes the misclassification
    %rate + tvf ratio. Will look to give user choice of which model to use.
    if optimizeFlag
        %First two hyper parameters to vary are window size and length.
        %These affect the WindowMeans feature extraction significantly.
        global best_mod_ratio;
        disp('~~~~~~');
        fprintf(['Model optimization is currently relatively limited.\n'...
            'It is only available for the ParadigmWindowmeans from BCILAB,'...
            'and the LDA classifier.\nThis optimization currently assumes'...
            'the following options are true for processing:\n'...
        '1.)There is an unequal number of \"target" to "non-target" classes, which will be balanced.\n'...
        '2.)The regularizer is set to maximize independent features\n'...
        '3.)The regularizer weight is strict (set at lambda = 1)\n'...
        '4.)The model will be optimized using a NON-EXHAUSTIVE grid search over window properties.\n']);
        disp('~~~~~~');
        disp('Performing simple model optimization for LDA. This can take a while...')
        
        %Provide initial train loss and tvfr values for the optimization as
        %a ratio.
        best_mod_ratio = 1/1; %This is TVFR on top, and trainloss on bottom.
        window_start = 0.15;
        %Size of the end of the window- Minimum of at least 350 ms, maximum
        %of 850 ms.
        window_endpoint = [.35:0.01:.85]; 
        %Length of the window step. Maximum size of 200 ms.
        winstep = [0.01:0.01:0.2];
        %Preallocate size of the output arrays.
        t_loss = zeros(length(window_endpoint),length(winstep));
        tvfr = zeros(length(window_endpoint),length(winstep));

        sz_a = length(window_endpoint);
        sz_b = length(winstep);
        %This is the standard nested for-loops. Want to parallelize this to
        %go faster...but have not had the time to improve it yet.
        for ii = 1:sz_a
          
            for jj = 1:sz_b
                
                % Define windows of interest
                wnds = [window_start:winstep(jj):window_endpoint(ii)];
                try
                wnds = reshape(wnds,2,[length(wnds)/2])';
                catch
                wnds = [window_start:winstep(jj):window_endpoint(ii)+winstep(jj)];
                wnds = reshape(wnds,2,[length(wnds)/2])';
                end
                %Define markers 
                optim_mrks = {'target', 'nontarget'};        
                %Use the basic approach
                optim_approach = {'Windowmeans', 'SignalProcessing', {'Rereferencing', 'on' ,'Resampling','off',...
                'EpochExtraction', {'TimeWindow', [0 0.8]},'FilterOrdering', {'flt_eog','flt_clean_channels','flt_clean_windows','flt_ica','flt_reref'}},...
                'Prediction', {'FeatureExtraction', {'TimeWindows', wnds},'MachineLearning',{...
                'Learner', {'lda' ... %This is where machine learning choices can be made
                            'Lambda', 1 ...
                            'Regularizer', 'independence' ...
                            'WeightedBias', true ...
                            'WeightedCov', true ...
                            'Robust', false}}}};  

                [trainloss, ~, laststats] = bci_train('Data', trainData, 'Approach',optim_approach, 'TargetMarkers', optim_mrks);
                tvf_ratio = (laststats.TP+laststats.TN)/(laststats.FP+laststats.FN);
                %See what the results give.
                t_loss(ii,jj) = trainloss;
                tvfr(ii,jj) = tvf_ratio;
                model_ratio = tvf_ratio/trainloss;
                if model_ratio > best_mod_ratio
                    %Update best model ratio
                    best_mod_ratio = model_ratio;
                    %Save results
                    best_model.trainloss = trainloss;
                    best_model.tvf_ratio = tvf_ratio;
                    best_model.window_params.endpoint = window_endpoint(ii);
                    best_model.window_params.stepsize = winstep(jj);
                end
                
%      parfor ii = 1:sz_a 
%          for jj = 1:sz_b
%                 %This was an attempt using parfor- still under
%                 %construction. Will uncomment out when it is finished!
%                 output = grid_search_p300_optimWindows(trainData,window_start,ii,jj);
%                 if ~isempty(output)
%                     optim_model(ii,jj) = output;
%                 end

            end %End in loop of window step length.
           disp('Inner loop iteration complete!');
        end %End outer loop of the window end size
           disp('Outer loop finished!');     
        %Now find the best pairs of trainloss and tvfr.
        wnds = [window_start:best_model.window_params.stepsize:best_model.window_params.endpoint];
        try
        wnds = reshape(wnds,2,[length(wnds)/2])';
        catch
        wnds = [window_start:best_model.window_params.stepsize:best_model.window_params.endpoint+best_model.window_params.stepsize];
        wnds = reshape(wnds,2,[length(wnds)/2])';
        end
        save('OptimizedModelParams.mat',best_model);
        
    else
        %%Use a predefined BCILAB Approach, and train the model
        % Define windows of interest
        wnds = [0.2:0.05:0.85];
        wnds = reshape(wnds,2,[length(wnds)/2])';
        
    end %End the optimization flag.
    
        %Define markers 
        mrks = {'target', 'nontarget'};
        %Define approach 
        %This is the old WindowMeans approach.
    %     approach = {'Windowmeans', 'SignalProcessing', {'EpochExtraction', {'TimeWindow', [0 0.8]},'FilterOrdering', {'flt_eog','flt_clean_channels','flt_clean_windows','flt_ica','flt_reref'},...
    %         'SpectralSelection', [0.1 15]}, 'Prediction', {'FeatureExtraction', {'TimeWindows', wnds}}};
        %This is just a more advaned P300 Windowed approach. This should work
        %in general better than the Window Means with no machine learning.
        fprintf('This approach has been verified only for a small number of data sets.\n The model approach should be altered if poor results are found.\n')
        approach = {'Windowmeans', 'SignalProcessing', {'Rereferencing', 'on' ,'Resampling','off',...
        'EpochExtraction', {'TimeWindow', [0 0.8]},'FilterOrdering', {'flt_eog','flt_clean_channels','flt_clean_windows','flt_ica','flt_reref'}},...
        'Prediction', {'FeatureExtraction', {'TimeWindows', wnds},'MachineLearning',{...
        'Learner', {'lda' ... %This is where machine learning choices can be made
                    'Lambda', 1 ...
                    'Regularizer', 'independence' ...
                    'WeightedBias', true ...
                    'WeightedCov', true ...
                    'Robust', false}}}};   
    
    
        %Learn model
        disp('Learning Model...');
        [trainloss, model, laststats] = bci_train('Data', trainData, 'Approach',approach, 'TargetMarkers', mrks);
        disp(['training mis-classification rate: ' num2str(trainloss*100,3) '%']);
        
        %Report the true positive/negative to false positive/negative ratio.
        tvf_ratio = (laststats.TP+laststats.TN)/(laststats.FP+laststats.FN);
        disp(['the true class v. false class ratio (tvfr): ' num2str(tvf_ratio)]);
        disp('higher tvfr values (>1) indicate better true class selection!')
        
        %Build a ROC curve from the last-stats data if the user sets the
        %visFlag in the options. This is false by default.
        %This has been hardcoded for the number of folds based on laststats.
        if visFlag
            disp('Visualizing ROC curve for each fold...')
            num_folds = length(laststats.per_fold);
            for ii = 1:num_folds
            %Get the target data
            t_for_roc = laststats.per_fold(ii).targ;
            %Make sure that only one target is set for each separate class.
            t_roc_1 = t_for_roc;
            t_roc_2 = t_for_roc;
            %set all 'non-target' (class 2) data to 0 for column 1.
            t_roc_1(t_roc_1==2) = 0;           
            %set all 'target' data (class 1) to 0 for column 2.
            t_roc_2(t_roc_2==1) = 0; 
            %Re-define class 2 so each 'non-target' is represented by '1'
            %in the data. (This is required to use in the ROC plot)
            t_roc_2(t_roc_2==2) = 1; 
            t_roc = [t_roc_1,t_roc_2];
            %Create a new figure for each fold
            figure(),
            %Plot the ROC for each fold of data.
            plotroc(t_roc',laststats.per_fold(ii).pred{1,2}');
            end
            disp('ROC Visualization complete!');
        end %End visualization flag.
    
end