function model = model_setup(filename, targetMarkerOrder)
    %%Calibrate BCILAB model using BCI_Train
    
    %Sanity checks
    [filepath, name, ext] = fileparts(filename);
    
    %Checking filename
    while ~ischar(filename) || ~strcmp(ext, {'.xdf'}) 
        disp('Incorrect filename format, must be a char array and have extension `.xdf`');
        filename = input('filename: ');
        [filepath, name, ext] = fileparts(filename);
    end
    
    %Checking Target Marker Order
    disp(isempty(targetMarkerOrder));
    while ~iscell(targetMarkerOrder) || isempty(targetMarkerOrder)
        disp('Incorrect Target Marker Order format, must be a string cell array');
        targetMarkerOrder = input('target marker order: ');
    end
    % Load in the XDF information to train a BCI Model
    % Must include specific target marker information in a cell array
    %trainData = eeg_load_xdf_ekl(filename, 'exclude_markerstreams', {'gUSBamp-1Markers'}, 'targetMarkerOrder', targetMarkerOrder);
    trainData = eeg_load_xdf_ekl_v2_RC(filename, 'exclude_markerstreams', {'gUSBamp-1Markers'}, 'targetMarkerOrder', targetMarkerOrder);

    %%Have BCILAB Approach Defined, and train the model
    % Define windows of interest
    %May have to change window size  
    wnds = [0.25 0.3; 0.3 0.35; 0.35 0.4; 0.4 0.45; 0.45 0.5; 0.5 0.55; 0.55 0.6];

    %Define markers 
    mrks = {'target', 'nontarget'};
    %Define approach 
    %This is the old WindowMeans approach.
%     approach = {'Windowmeans', 'SignalProcessing', {'EpochExtraction', {'TimeWindow', [0 0.8]},...
%         'SpectralSelection', [0.1 15]}, 'Prediction', {'FeatureExtraction', {'TimeWindows', wnds}}};
    %This is just the default DALERP approach. This should work in general
    %better than the Window Means.
    approach = {'DALERP','SignalProcessing',{'EpochExtraction',[0 0.8]}};
    %Learn model
    disp('Learning Model...');
    [trainloss, model, laststats] = bci_train('Data', trainData, 'Approach', approach, 'TargetMarkers', mrks);
    disp(['training mis-classification rate: ' num2str(trainloss*100,3) '%']);

end