% Welcome message----------------------------------------------------------
disp(' ')
disp('Welcome to the Test Controller for the P300-Unity-LSL-USBamp system!')
disp('Here you will enter some configuration details for the test controller.')
disp('*Note: make sure all g.tec files are removed from the path before running*')
disp(' ')


% P300 Type------------------------------------------------------------------------------ 
%   Either 'SingleFlash' or 'RCFlash'
%   SingleFlash for Single P300 flashes, RCFlash for Row/Column P300 flashes
P300_type = input('Enter P300 paradigm type (SingleFlash or RCFlash): ', 's'); % Get User input
while ~strcmpi(P300_type, 'SingleFlash') && ~strcmpi(P300_type, 'RCFlash')
    P300_type = input('Incorrect input! Please enter SingleFlash or RCFlash: ','s');
end

% Setup BCILAB------------------------------------------------------------- 
%   Set as true to run BCILAB and EEGLAB configurations 
%   If BCILAB and EEGLAB are already configured in the current Matlab
%   session, set as false.
BCILab_setup = false;
BCILab_setup_str = input('\nDo you need to setup BCILab (Y or N)?: ', 's');

%   Check for correct input
while ~strcmpi(BCILab_setup_str, 'Y') && ~strcmpi(BCILab_setup_str, 'N')
    BCILab_setup_str= input('Incorrect input! Please enter Y for yes or N for no: ','s');
end

%   Set BCILab_setup as true or false depending on the input 
if BCILab_setup_str == 'Y'
    BCILab_setup = true;
elseif BCILab_setup_str == 'N'
    BCILab_setup = false; 
end

% Training Data------------------------------------------------------------ 
%   Get name of the training data set 
%   Must be an xdf file format
runGetFileName = true;
while runGetFileName
    train_data_filepath = input('\nPlease enter filepath for training data: ', 's'); 
    train_data_filename = input('Please enter filename for training data (*Note* must be an .xdf file format): ', 's'); 

%   Check that file is .xdf extension
    [~, ~, input_ext] = fileparts(train_data_filename);
    while ~strcmpi(input_ext, '.xdf')
        train_data_filename = input('Are you sure you entered an .xdf file? Try again: ', 's'); 
        [~, ~, input_ext] = fileparts(train_data_filename); 
    end

%   Combine folder and filename
    train_data = strcat(train_data_filepath,'\',train_data_filename); 

%   Confirm with user
    disp('This is the filepath you entered...')
    disp(train_data)
    check = input('Is this correct (Y or N)?', 's'); 
    
%   Check uesr input
    while ~strcmpi(check, 'Y') && ~strcmpi(check, 'N')
        check = input('Incorrect input! Please enter Y for yes or N for no: ','s');
    end
   
%   Depending on the input, continue or exit the loop 
    if strcmpi(check, 'N')
        runGetFileName = true;
    else
        runGetFileName = false;
    end
end

% Target Markers-----------------------------------------------------------
%   Get the order of the target markers from the training session
runInputMarkers = true;
while runInputMarkers
%   Get number of training trials
    num_trials = input('\nPlease enter the number of training trials: ');

%   Empty cell/list to hold markers
    target_markers = cell(1, num_trials);
    target_marker_list = [];

%   For each trial, get marker index 
    for i = 1:num_trials 
        prompt = strcat('Please enter the index of the target cube for trial_', int2str(i), ': ');
        target_index = input(prompt); 
        target_markers{i} = strcat('s,', int2str(target_index)); % put in 's,idx' format
        target_marker_list(i)=target_index; % add to list for displaying later
    end
%   Check user input
    disp('You entered: ')
    disp(target_marker_list)
    check = input('Do you want to make a change (Y or N)?: ', 's');
    while ~strcmpi(check, 'Y') && ~strcmpi(check, 'N')
    check = input('Incorrect input! Please enter Y for yes or N for no: ','s');
    end
%   Depending on the input, continue or exit the loop 
    if strcmpi(check, 'Y')
        runInputMarkers = true;
    else
        runInputMarkers = false;
    end
end

% Run test_controller 
disp(' ')
disp('...')
disp('Running test_controller...') 
test_controller(P300_type, BCILab_setup, train_data, target_markers)
