function [numRows, numColumns, numFlashes, s_numTrials, ...
    rc_numTrials] = lsl_unity_information()
    disp('Obtaining Session Information from Unity...');
    disp('.....Loading the LSL Library...');
    lib = lsl_loadlib();
    
    disp('.....Resolving a Stream from Unity...');
    result = {};
    while isempty(result)
        result = lsl_resolve_byprop(lib, 'type', 'LSL_Marker_Strings');
    end
    
    disp('.....Opening an inlet...');
    inlet = lsl_inlet(result{1});
    
    information = {};
    disp('.....Receiving information from Unity');
    while size(information, 2) < 5
        [info, ts] = inlet.pull_sample();
        information{end+1} = info;
    end
    disp('Information collected...');
    disp(['NumRows: ', information{1}]);
    numRows = str2num(char(information{1}));
    disp(['NumColumns: ', information{2}]);
    numColumns = str2num(char(information{2}));
    disp(['Number of Cube Flashes: ', information{3}]);
    numFlashes = str2num(char(information{3}));
    disp(['Number of SingleFlash Trials: ', information{4}]);
    s_numTrials = str2num(char(information{4}));
    disp(['Number of RCFlash Trials: ', information{5}]);
    rc_numTrials = str2num(char(information{5}));
end