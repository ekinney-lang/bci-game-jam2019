%%  TEST_CONTROLLER
%   Main Controller for BCI-Unity communications. Sets up LSL Inlets and
%   Outlets. Carries BCILAB functions. 
%
%   test_controller(Type, Setup, CalibData, TargetMarkers)
%   
%   In:
%     Type: Either SingleFlash or RCFlash. SingleFlash for Single P300 Flashes.
%           RCFlash for Row/Column P300 Flashes. Default is SingleFlash.
%     Setup: true to run BCILAB and EEGLAB configurations. 
% 
%            false if BCILAB and EEGLAB are already configured in current session. 
%            Default is false.
% 
%     CalibData: Calibration data from training session. Must be an xdf
%                file format. Default is an empty string which will then 
%                be caught and the user will be asked to input a valid file.
%
%     TargetMarkers: Order of Target Markers from training session. Must be
%                    a nonempty string cell array. Default is an empty cell 
%                    array which will then be caught and the user will be 
%                    asked to input a valid cell array.
%
% Examples: 
%   % First time running this program in a single session with SingleFlash
%   test_controller('Type', 'SingleFlash', 'Setup', true, 'CalibData', 
%         'D:/Users/BCI-Agent Smith/Desktop/TestRealData/sm_13June_T1.xdf',
%         'TargetMarkers',  {'s,5', 's,7', 's,8', 's,3', 's,6', 's,7', 
%         's,2', 's,6', 's,2', 's,3'});
%
%   % Second time running this program
%   test_controller('CalibData', 
%         'D:/Users/BCI-Agent Smith/Desktop/TestRealData/sm_13June_T1.xdf',
%         'TargetMarkers',  {'s,5', 's,7', 's,8', 's,3', 's,6', 's,7', 
%         's,2', 's,6', 's,2', 's,3'});

function test_controller(varargin)
    global runSim;
    global flash_chunk;
    global rcFlash;
    global predictions;
    
    %This will first find out if the "arg" function from bcilab is
    %currently available on the path. If not, it will run BCILab set-up,
    %then continue forward. Otherwise it behaves as expected.
    %Define arguments
    try
        opts = arg_define(varargin, ...
        arg({'type', 'Type'}, 'SingleFlash', [], 'Type of Flash, either SingleFlash or RCFlash'),...
        arg({'setup', 'Setup'}, false, [], 'Determine whether or not to run bci_setup and eeglab'),...
        arg({'calib_data', 'CalibData'}, 'empty' , [], 'Calibration data from training'),...
        arg({'tm_order', 'TargetMarkers'}, {}, [], 'Target Marker Order from training'));
        
    catch
        bci_setup;
        opts = arg_define(varargin, ...
        arg({'type', 'Type'}, 'SingleFlash', [], 'Type of Flash, either SingleFlash or RCFlash'),...
        arg({'setup', 'Setup'}, false, [], 'Determine whether or not to run bci_setup and eeglab'),...
        arg({'calib_data', 'CalibData'}, 'empty' , [], 'Calibration data from training'),...
        arg({'tm_order', 'TargetMarkers'}, {}, [], 'Target Marker Order from training'));
        %Set the 'setup to false'
        opts.setup = false;
    end
    
    %Type Sanity Checks:
    while ~strcmpi(opts.type, 'SingleFlash') && ~strcmpi(opts.type, 'RCFlash')
       disp('Incorrect Type, please enter either `SingleFlash` or `RCFlash`');
       opts.type = input('Type: ');
    end
    
    %%Can toggle BCISETUP on/off, on for initial MATLAB set up, and off for
    %repeated simulations. This is just redundant code, which lets the user
    %re-setup BCILAB if needed.
    if opts.setup
        bci_setup;
    end
    
    %%Calibrate BCILAB model using BCI_Train
    %Takes in calibration filename and targetmarker order as parameters
    %Returns calibrated model to be used in predictions
    lastmodel = model_setup(opts.calib_data, opts.tm_order);
    
    %%LSL Outlet configuration 
    %Returns the configured outlet to be used during predictions
    u_outlet = lsl_outlet_setup();
    
    %%Obtain initial Unity set up and information for first trial
    [numRows, numColumns, numFlashes, s_numFlashes, rc_numFlashes] = lsl_unity_information();
    
    %Configure variables for prediction model and pairing 
    numCubes = numRows * numColumns;
    
    %Variable is how many times we're running this simulation, to be
    %removed for realtime trials
    %numTrials = 10;
    
    %Creating part of cube_map and testmarks
    for i=1:numCubes
        single_cubes{i} = char(sprintf('%s%d', 's,',i-1));
    end
    
    if strcmpi(opts.type, 'SingleFlash')
        testmrks = single_cubes;
        numIterations = numCubes * numFlashes;
        numFlashes = s_numFlashes;
    else
        % Create the matrix
        cube_matrix = (reshape(1:(numColumns * numRows), numColumns, numRows)-1)';

        %Create row and column indices in a cell array
        %Assigning Row values
        for row = 1:numRows
            testmrks{row} = 'r';
            for col = 1:numColumns
                testmrks{row} = char(sprintf('%s,%d', testmrks{row}, cube_matrix(row, col)));
            end
        end
        %Assigning Column values
        % testrcmrks = {'c,0,3,6', 'c,1,4,7','c,2,5,8','r,0,1,2','r,3,4,5','r,6,7,8'};
        for col = 1:numColumns
            testmrks{col+numRows} = 'c';
            for row = 1:numRows
                testmrks{col+numRows} = char(sprintf('%s,%d', testmrks{col + numRows}, cube_matrix(row, col)));
            end
        end
        %Check if this works for non square matrices
        numIterations = rc_numFlashes;
        %numIterations = (numRows + numColumns) * (numFlashes/2);
    end
    
    %CHANGE THIS FOR THE LIVE DEMO TO LSL_MARKER_STRINGS
    %run_readlsl_sm('DataStreamQuery', 'type=''EEG''', 'MarkerQuery', 'type=''Markers''');
    run_readlsl_sm('DataStreamQuery', 'type=''EEG''', 'MarkerQuery', 'type=''LSL_Marker_Strings''');
    % this stream can be read anywhere on the network (using LSL for MATLAB, Python, C, C++, Java or C#)
    run_writelsl('Model',lastmodel,'LabStreamName','BCI-Continuous','PredictAt', testmrks, 'Verbose', true);


    %cube_map = {'s,0', 's,1', 's,2', 's,3', 's,4', 's,5', 's,6', 's,7', 's,8';0,0,0,0,0,0,0,0,0};
    %Creating cube_matrix dynamically
    for i = 1:numCubes
        cube_map{1,i} = single_cubes{i};
        cube_map{2,i} = 0;
    end
    
    %%Obtain predictions from LSL and pair with markers to obtain a prediction
    runSim = false;
    rcFlash = false;
    tcounter = 0;
    disp('Waiting for Markers to come in');
    
    %Adapt the number of numTrials expected to how many were received.
%     disp("There was a discrepency between number of iterations expected and number received. Going to use just the number received");
%     numIterations = size(predictions,2);
%     
    %CHANGE THIS FOR THE LIVE DEMO
    %while tcounter < numIterations 
    while true
        %If the size of predictions is a factor of numIterations (to ensure
        %chunks)
        if runSim
            p_buffer = predictions;
             if mod(size(p_buffer, 2), numIterations) == 0
                disp('Checking chunk');
                p_index = (tcounter * numIterations) + 1;
                %Pull chunk from predictions array
                p_chunk = p_buffer(p_index:((tcounter + 1) * numIterations));
                %For every flash in the flash_chunk, find the corresponding string
                %in the cube map and increment the probability values
                disp('Iterating through chunk');
                %If chunk is part of a RC flash, then split the strings into
                %their respective cubes
                if rcFlash
                    for j = 1:numIterations
                        %Split the string by ','
                        split_cubes = strsplit(char(flash_chunk{1}{j}), ',');
                        %Remove the first index, it contains the classifier
                        %which is not needed
                        split_cubes(1) = [];

                        char_cubes = cell(1, size(split_cubes, 2));
                        %char_cubes = {};
                        %For every cube in the split_cubes list, append 's,' to
                        %it and increment the probability value
                        for k = 1:size(split_cubes, 2)
                            char_cubes{k} = strcat('s,', char(split_cubes(k)));
                            cm_index = find(strcmpi(cube_map(1,:),char_cubes{k}));
                            cube_map{2, cm_index} = cube_map{2, cm_index} + p_chunk{j};
                        end
                    end
                else
                    %Single Flash, find the string in the cube map and
                    %increment the probability value
                    for j = 1:numIterations 
                        cm_index = find(strcmpi(cube_map(1, :), flash_chunk{1}{j}));
                        cube_map{2, cm_index} = cube_map{2, cm_index} + p_chunk{j};
                    end
                end

                tcounter = tcounter + 1;

                %Check to see which cube has the highest probability (by taking the
                %minimum value)
                disp('Finding Minimum Value');
                [sc_value, sc_index] = min(cell2mat(cube_map(2, :)));
                selected_cube = cube_map{1, sc_index};
                disp(selected_cube);
                u_outlet.push_sample({selected_cube});

                %Reset the values of the cube_map, can be done by either assigning
                %a clean slate to the cube_map variable, or just overwriting each
                %value
                disp('Resetting Cube Map');
                for k = 1:size(cube_map, 2)
                    cube_map{2, k} = 0;
                end
                runSim = false;
% 
%             else
%                 disp("There was a discrepency between number of iterations expected and number received. Going to use just the number received");
%                 disp('Checking chunk');
%                 numIterations = size(p_buffer,2);
%                 p_index = (tcounter * numIterations) + 1;
%                 %Pull chunk from predictions array
%                 p_chunk = p_buffer(p_index:((tcounter + 1) * numIterations));
%                 %For every flash in the flash_chunk, find the corresponding string
%                 %in the cube map and increment the probability values
%                 disp('Iterating through chunk');
%                 %If chunk is part of a RC flash, then split the strings into
%                 %their respective cubes
%                 if rcFlash
%                     for j = 1:numIterations
%                         %Split the string by ','
%                         split_cubes = strsplit(char(flash_chunk{1}{j}), ',');
%                         %Remove the first index, it contains the classifier
%                         %which is not needed
%                         split_cubes(1) = [];
% 
%                         char_cubes = cell(1, size(split_cubes, 2));
%                         %char_cubes = {};
%                         %For every cube in the split_cubes list, append 's,' to
%                         %it and increment the probability value
%                         for k = 1:size(split_cubes, 2)
%                             char_cubes{k} = strcat('s,', char(split_cubes(k)));
%                             cm_index = find(strcmpi(cube_map(1,:),char_cubes{k}));
%                             cube_map{2, cm_index} = cube_map{2, cm_index} + p_chunk{j};
%                         end
%                     end
%                 else
%                     %Single Flash, find the string in the cube map and
%                     %increment the probability value
%                     for j = 1:numIterations 
%                         cm_index = find(strcmpi(cube_map(1, :), flash_chunk{1}{j}));
%                         cube_map{2, cm_index} = cube_map{2, cm_index} + p_chunk{j};
%                     end
%                 end
% 
%                 tcounter = tcounter + 1;
% 
%                 %Check to see which cube has the highest probability (by taking the
%                 %minimum value)
%                 disp('Finding Minimum Value');
%                 [sc_value, sc_index] = min(cell2mat(cube_map(2, :)));
%                 selected_cube = cube_map{1, sc_index};
%                 disp(selected_cube);
%                 u_outlet.push_sample({selected_cube});
% 
%                 %Reset the values of the cube_map, can be done by either assigning
%                 %a clean slate to the cube_map variable, or just overwriting each
%                 %value
%                 disp('Resetting Cube Map');
%                 for k = 1:size(cube_map, 2)
%                     cube_map{2, k} = 0;
%                 end
%                 runSim = false;
%                 
            end % End mod(p_buffer size).
        end
    end %End while true loop-
    sprintf('Markers all sent!')
end
