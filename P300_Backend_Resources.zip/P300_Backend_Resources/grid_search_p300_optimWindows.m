function output = grid_search_p300_optimWindows(trainData,window_start,window_endpoint,winstep)
%This is a function to be run with model_setup to allow a parfor loop to
%analyze the data.


%Get the global variable for best model ratio
    global best_mod_ratio
    % Define windows of interest
    wnds = [window_start:winstep:window_endpoint];
    try
    wnds = reshape(wnds,2,[length(wnds)/2])';
    catch
    wnds = [window_start:winstep(jj):window_endpoint+winstep];
    wnds = reshape(wnds,2,[length(wnds)/2])';
    end

    %Define markers 
    optim_mrks = {'target', 'nontarget'};        
    %Use the basic approach
    optim_approach = {'Windowmeans', 'SignalProcessing', {'Rereferencing', 'on' ,'Resampling','off',...
    'EpochExtraction', {'TimeWindow', [0 0.8]},'FilterOrdering', {'flt_eog','flt_clean_channels','flt_clean_windows','flt_ica','flt_reref'}},...
    'Prediction', {'FeatureExtraction', {'TimeWindows', wnds},'MachineLearning',{...
    'Learner', {'lda' ... %This is where machine learning choices can be made
                'Lambda', 1 ...
                'Regularizer', 'independence' ...
                'WeightedBias', true ...
                'WeightedCov', true ...
                'Robust', false}}}};  

    [trainloss, ~, laststats] = bci_train('Data', trainData, 'Approach',optim_approach, 'TargetMarkers', optim_mrks);
    tvf_ratio = (laststats.TP+laststats.TN)/(laststats.FP+laststats.FN);
    
    model_ratio = tvf_ratio/trainloss;
    if model_ratio > best_mod_ratio
        %Update best model ratio
        best_mod_ratio = model_ratio;
        %Save results
        best_model.trainloss = trainloss;
        best_model.tvf_ratio = tvf_ratio;
        best_model.window_params.endpoint = window_endpoint(ii);
        best_model.window_params.stepsize = winstep(jj);
        output = best_model;      
    else
        output = [];
    end


end