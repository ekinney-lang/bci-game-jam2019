function lslStreamSimulator(setup, filename)
    %Run BCI Setup which will add necessary libraries needed for LSL stream
    %with BCILAB
    if setup
        bci_setup;
    end
    
    disp('Online Simulation...');
    %Sanity checks
    [filepath, name, ext] = fileparts(filename);
    
    if ~ischar(filename) || ~strcmp(ext, {'.xdf'}) 
        disp('Incorrect filename format, must be a char array and have extension `.xdf`');
        return;
    end
    
    % Load data set:
    testData = io_loadset_ekl(filename, 'exclude_markerstreams', {'gUSBamp-1Markers'});
    %testData = io_loadset_ekl('D:/Users/BCI-Agent Smith/Desktop/TestRealData/sm_13June_T2.xdf', 'exclude_markerstreams', {'gUSBamp-1Markers'}); 
    %testData = io_loadset_ekl('D:/Users/BCI-Agent Smith/Desktop/TestRealData/sm_13June_T1.xdf', 'exclude_markerstreams', {'gUSBamp-1Markers'}); 
    %testData = io_loadset_ekl('D:/Users/BCI-Agent Smith/Desktop/TestRealData/sm_13June_T3.xdf', 'exclude_markerstreams', {'gUSBamp-1Markers'}); 

    play_eegset_lsl('Dataset',testData, 'Looping', false, 'DisplayMarkers', true, 'Speedup', 10);

end