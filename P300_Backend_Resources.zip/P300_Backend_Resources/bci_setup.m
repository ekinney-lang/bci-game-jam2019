function bci_setup()
    disp('Setting up BCILAB and EEGLAB...');
    bcilab;
    eeglab;
    disp('BCILAB and EEGLAB setup complete...');
end